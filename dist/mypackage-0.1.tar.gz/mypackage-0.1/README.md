# my package
This library was created as a test, not sure how it works yet but we will find out.

# How to install